#!/usr/bin/env python3
"""Inject a story JSON into the player template -> one self-contained HTML file.

Usage: python3 build.py story.json output.html
Checks the story for common mistakes before building.
"""
import json, sys, pathlib, re

HERE = pathlib.Path(__file__).resolve().parent
TEMPLATE = HERE.parent / "assets" / "player.html"
OPS = {"spawn", "move", "set", "glow", "unglow", "dim", "undim", "remove", "bad", "ok",
       "count", "confetti", "clear", "sound"}


def check(story):
    errs, warns = [], []
    for k in ("title", "problem_zh", "scenes"):
        if k not in story:
            errs.append(f"missing top-level field: {k}")
    scenes = story.get("scenes", [])
    if not 6 <= len(scenes) <= 16:
        warns.append(f"{len(scenes)} scenes — aim for 8–12")
    has_bad = has_ok = has_think = False
    for i, s in enumerate(scenes):
        lines = s.get("lines") or [s]
        for j, l in enumerate(lines):
            tag = f"scene {i}" + (f" line {j}" if "lines" in s else "")
            if not l.get("zh"):
                errs.append(f"{tag}: missing zh caption")
            if len(l.get("zh", "")) > 40:
                warns.append(f"{tag}: zh caption {len(l['zh'])} chars — keep under ~32 for phones")
            if "lines" in s and l.get("s") not in ("Q", "A"):
                errs.append(f"{tag}: speaker 's' must be \"Q\" or \"A\"")
            if re.search(r"[✓✗✔✘≤≥]", l.get("zh", "") + l.get("en", "")):
                warns.append(f"{tag}: caption uses ✓✗≤≥ — some phone fonts miss them; use words")
        n_lines = len(lines)
        for op in s.get("ops", []):
            if op.get("line", 0) >= n_lines:
                errs.append(f"scene {i}: op {op.get('op')} has line={op['line']} but scene has {n_lines} line(s)")
        if s.get("think"):
            has_think = True
        for op in s.get("ops", []):
            for k in ("text", "prefix", "suffix"):
                if re.search(r"[\u4e00-\u9fff]", str(op.get(k, ""))) and f"{k}_en" not in op:
                    warns.append(f"scene {i}: {op.get('op')} {op.get('id')} has Chinese {k} but no {k}_en — English mode will show Chinese")
            if op.get("op") not in OPS:
                errs.append(f"scene {i}: unknown op {op.get('op')!r}")
            if op.get("op") == "bad":
                has_bad = True
            if op.get("op") in ("ok", "confetti"):
                has_ok = True
            if op.get("op") == "spawn" and "x" not in op:
                errs.append(f"scene {i}: spawn {op.get('id')} needs x,y")
            for axis in ("x", "y"):
                v = op.get(axis)
                if isinstance(v, (int, float)) and not 4 <= v <= 96:
                    warns.append(f"scene {i}: {op.get('id')} {axis}={v} is near/over the stage edge")
    if not has_bad:
        warns.append("no 'bad' op — show the common wrong answer and where it breaks")
    if not has_ok:
        warns.append("no 'ok'/'confetti' — celebrate the verified answer")
    if not has_think:
        warns.append("no scene with 'think' — end with a pause-and-think challenge")
    return errs, warns


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    story = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
    errs, warns = check(story)
    for w in warns:
        print("WARN ", w)
    for e in errs:
        print("ERROR", e)
    if errs:
        sys.exit(1)
    html = TEMPLATE.read_text(encoding="utf-8")
    data = json.dumps(story, ensure_ascii=False).replace("</", "<\\/")
    html = html.replace("/*__STORY__*/null", data).replace("__TITLE__", story["title"])
    pathlib.Path(sys.argv[2]).write_text(html, encoding="utf-8")
    print(f"built {sys.argv[2]} ({len(story['scenes'])} scenes)")


if __name__ == "__main__":
    main()
