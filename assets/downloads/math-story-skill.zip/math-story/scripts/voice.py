#!/usr/bin/env python3
"""Add Microsoft neural voice narration (free, via edge-tts) to a story JSON.

Usage:
  pip install edge-tts            # once
  python3 voice.py story.json [voiced.json] [--zh VOICE] [--en VOICE] [--zh-q VOICE] [--en-q VOICE]

Scenes with "lines" (Q&A dialogue) get one clip per line: speaker "Q" (asker, boy by
default) and "A" (answerer, girl by default) use different voices.

Writes STORY["audio"] = {"zh": [base64 mp3 per scene], "en": [...]}; build.py embeds it
into the HTML so narration works offline and gets captured by screen recording.
Needs internet access to Microsoft's speech service from the computer running it.

Voices (free):
  zh girl  zh-CN-XiaoyiNeural (default)   zh boy  zh-CN-YunxiaNeural
  zh woman zh-CN-XiaoxiaoNeural           zh man  zh-CN-YunxiNeural
  en girl  en-US-AnaNeural (default)      en man  en-US-AndrewNeural
"""
import argparse, asyncio, base64, json, pathlib, sys

try:
    import edge_tts
except ImportError:
    sys.exit("edge-tts not installed: run  pip install edge-tts")

SPOKEN = {"×": {"zh": "乘", "en": " times "}, "÷": {"zh": "除以", "en": " divided by "},
          "−": {"zh": "减", "en": " minus "}, "=": {"zh": "等于", "en": " equals "}}


def spoken(text, lang):
    for sym, words in SPOKEN.items():
        text = text.replace(sym, words[lang])
    return text


async def synth(text, voice, rate, pitch="+0Hz", tries=3):
    last = None
    for attempt in range(tries):
        try:
            audio = b""
            async for chunk in edge_tts.Communicate(text, voice, rate=rate, pitch=pitch).stream():
                if chunk["type"] == "audio":
                    audio += chunk["data"]
            if audio:
                return audio
        except Exception as e:  # NoAudioReceived happens now and then; retry
            last = e
        await asyncio.sleep(1 + attempt)
    raise RuntimeError(f"no audio for {text!r}: {last}")


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("story"); ap.add_argument("out", nargs="?")
    ap.add_argument("--zh", default="zh-CN-XiaoyiNeural", help="narrator / answerer (A) Chinese voice")
    ap.add_argument("--en", default="en-US-AnaNeural", help="narrator / answerer (A) English voice")
    ap.add_argument("--zh-q", default="zh-CN-YunxiaNeural", help="asker (Q) Chinese voice")
    ap.add_argument("--en-q", default="en-US-AndrewNeural", help="asker (Q) English voice")
    ap.add_argument("--rate", default="-5%")
    ap.add_argument("--only", choices=["zh", "en"])
    a = ap.parse_args()
    path = pathlib.Path(a.story)
    story = json.loads(path.read_text(encoding="utf-8"))
    voices = {("zh", "A"): (a.zh, a.rate, "+0Hz"), ("zh", "Q"): (a.zh_q, a.rate, "+0Hz"),
              ("en", "A"): (a.en, a.rate, "+0Hz"),
              # no free US child boy voice exists: lift a young adult male voice a little
              ("en", "Q"): (a.en_q, "+5%" if a.en_q == "en-US-AndrewNeural" else a.rate,
                            "+40Hz" if a.en_q == "en-US-AndrewNeural" else "+0Hz")}
    audio = story.get("audio", {})
    for lang in ("zh", "en"):
        if a.only and lang != a.only:
            continue
        clips = []
        for i, s in enumerate(story["scenes"]):
            if "lines" in s:   # Q&A dialogue: one clip per line, voice by speaker
                per = []
                for j, l in enumerate(s["lines"]):
                    text = l.get(f"say_{lang}") or l.get(lang) or ""
                    voice, rate, pitch = voices[(lang, l.get("s", "A"))]
                    mp3 = await synth(spoken(text, lang), voice, rate, pitch) if text else b""
                    per.append(base64.b64encode(mp3).decode() if mp3 else None)
                    print(f"{lang} scene {i} line {j} ({l.get('s', 'A')}): {len(mp3)//1024} KB")
                clips.append(per)
            else:
                text = s.get(f"say_{lang}") or s.get(lang) or ""
                voice, rate, pitch = voices[(lang, "A")]
                mp3 = await synth(spoken(text, lang), voice, rate, pitch) if text else b""
                clips.append(base64.b64encode(mp3).decode() if mp3 else None)
                print(f"{lang} scene {i}: {len(mp3)//1024} KB")
        audio[lang] = clips
    story["audio"] = audio
    story["voices"] = {f"{k[0]}-{k[1]}": v[0] for k, v in voices.items()}
    out = pathlib.Path(a.out or path)
    out.write_text(json.dumps(story, ensure_ascii=False), encoding="utf-8")
    print(f"voiced story written to {out}")


if __name__ == "__main__":
    asyncio.run(main())
